package defaul;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Controlador {
	private Vista vista;
	private Modelo modelo;


	public Controlador(Vista vista, Modelo modelo){
		this.vista = vista;
		this.modelo = modelo;
		 inicializarVista();
		 initEventHandlers();
		//* initEventHandlers2();
		}
	 private void inicializarVista() {
	      
	        File archivo = Modelo.leerFichero(); 
	        ArrayList<String> lineas = Modelo.leerTexto(archivo);         
	        String contenido = String.join("\n", lineas);
	        vista.getTextAreaOriginal().setText(contenido);
	    }
	 
	 public void initEventHandlers(){
		 vista.getBtnBuscar().addActionListener(new ActionListener() {
		 public void actionPerformed(ActionEvent arg0) {
		String palabrabuscada =  vista.getTextFieldBuscar().getText();
		int contador = Modelo.buscarPalabras(palabrabuscada);
		JOptionPane.showMessageDialog(vista.getTextAreaOriginal(),"Palabra: " + palabrabuscada + " aparece " + contador + " veces");
		  
		 }
		 });

}
	 
	 public void initEventHandlers2(){
		//*  vista.getBtnReemplazar().addActionListener(new ActionListener() {
		//* public void actionPerformed(ActionEvent arg0) {
		//*String palabrareemplazada =  vista.getTextFieldReemplazar().getText();
		//*Modelo.reemplazarPalabra(palabrareemplazada);
		//*	JOptionPane.showMessageDialog(vista.getTextAreaOriginal(),"");
		  
		//* }
	//* });

}
}