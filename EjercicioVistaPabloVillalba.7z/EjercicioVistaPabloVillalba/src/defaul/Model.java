package defaul;

public class Model extends Vista {

}
