package defaul;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

public class Modelo {

	static String ruta = "C:\\\\\\\\Users\\\\\\\\DAM2\\\\\\\\eclipse-workspace\\\\\\\\EjercicioVista\\\\\\\\texto.txt";
	static File archivo = new File(ruta);
	
	public Modelo(){
		
	}
	
	public static File leerFichero() {
	    String ruta = "C:\\\\Users\\\\DAM2\\\\eclipse-workspace\\\\EjercicioVista\\\\texto.txt";
	    return new File(ruta);
	}
	public static ArrayList<String> leerTexto(File archivo) {
	    ArrayList<String> lineas = new ArrayList<String>();

	   

	    
	    try (FileReader lector = new FileReader(archivo);
	         BufferedReader br = new BufferedReader(lector)) {
	        String linea;
	        while ((linea = br.readLine()) != null) {
	            lineas.add(linea); 
	        }
	    } catch (Exception e) {
	        e.printStackTrace(); 
	    }
	    return lineas; 
	}
	public static ArrayList<String> reemplazarPalabra(ArrayList<String> lineas, String palabraBuscada, String palabraReemplazo) {
	    ArrayList<String> lineasModificadas = new ArrayList<>();

	    
	    for (String linea : lineas) {
	       
	        String lineaModificada = linea.replaceAll("\\b" + palabraBuscada + "\\b", palabraReemplazo);
	        lineasModificadas.add(lineaModificada); 
	    }

	    return lineasModificadas; 
	}
	
	public static int buscarPalabras(String palabra) {
		  ArrayList<String> lineas = new ArrayList<String>();

		   

		    
		    try (FileReader lector = new FileReader(archivo);
		         BufferedReader br = new BufferedReader(lector)) {
		        String linea;
		        while ((linea = br.readLine()) != null) {
		            lineas.add(linea); 
		        }
		    } catch (Exception e) {
		        e.printStackTrace(); 
		    }
		
		int contador = 0;
		 for (String linea : lineas) {
			 String[] palabrasEnLinea = linea.toLowerCase().split("\\W+");
			 for (String palabraEnLinea : palabrasEnLinea) {
		            if (palabraEnLinea.equals(palabra)) {
		                contador++;
		            }
		        }
		       
		} 
		return contador;
		
	}
	
	
	}




