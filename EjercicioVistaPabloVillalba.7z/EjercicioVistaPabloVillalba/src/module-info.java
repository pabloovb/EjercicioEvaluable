/**
 * 
 */
/**
 * 
 */
module EjercicioVista {
	requires java.desktop;
}