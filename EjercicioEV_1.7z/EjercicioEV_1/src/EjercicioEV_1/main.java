package EjercicioEV_1;

import java.io.File;
import java.util.Date;
import java.util.Scanner;

public class main {
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Hola, indica tu directorio");
		String directorio = teclado.next();

		System.out.println("Indica qué quieres realizar: ");
		System.out.println("1: Mostrar toda la información de tu directorio ");
		System.out.println("2: Crear carpeta");
		System.out.println("2: Crear archivo");
		System.out.println("4: Eliminar");
		System.out.println("5: Renombrar");
		int eleccion = teclado.nextInt();
		
		switch (eleccion) {
		case 1: {
			getInformacion(directorio);
			
			
		} teclado.next();
		
		case 2: {
			creaCarpeta(directorio);
		}
		
		case 3:{
			creaArchivo(directorio);
		}
		
		case 4:{
			eliminar(directorio);
		}
		
		case 5: {
			renombrar(directorio);
		}
			
		
		
	}
		}
	
	public static void getInformacion(String directorio) {
		Scanner teclado = new Scanner(System.in);
		
		
		
		
		File archivo = new File(directorio);
		
		if(archivo.exists() == true) {
			
		
		System.out.println("Nombre: " + archivo.getName());
		if(archivo.isDirectory() == true) {
			System.out.println("Es un directorio");
			System.out.println("Espacio disponible: " + archivo.getUsableSpace());
			System.out.println("Espacio total: " + archivo.getTotalSpace());
			String[] listado = archivo.list();
			for (int i=0; i< listado.length; i++) {
		        System.out.println(listado[i]);
		    }
		}else if (archivo.isDirectory() == false) {
			System.out.println("Es un archivo");
			System.out.println("Tamaño: " + archivo.length());
		}
		System.out.println("Ubiacion: " + archivo.getAbsolutePath());
		
		Date d = new Date(archivo.lastModified());
		System.out.println("Ultima fecha de modificacion: " + d.getDay() + "/" +  d.getMonth() + "/" + d.getYear());
		
	} else {
		System.out.println("No existe el directorio");}
	}
	
	public static void creaCarpeta(String directorio) {
		Scanner teclado = new Scanner(System.in);
		
		File archivo = new File(directorio);
		
		System.out.println("Di el nombre que quieres asignar");
		String nombre = teclado.next();
		File nuevonombre = new File(nombre);
		try {
			if (nuevonombre.mkdir())
				   System.out.println("La carpeta se ha creado correctamente");
				 else
				   System.out.println("No ha podido ser creado el fichero");
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		
	}
	
	public static void creaArchivo(String directorio) {
		Scanner teclado = new Scanner(System.in);
		
		File archivo = new File(directorio);
		
		System.out.println("Di el nombre que quieres asignar");
		String nombre = teclado.next();
		File nuevonombre = new File(nombre);
		try {
			if (nuevonombre.createNewFile())
				   System.out.println("El fichero se ha creado correctamente");
				 else
				   System.out.println("No ha podido ser creado el fichero");
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	public static void eliminar(String directorio) {
		Scanner teclado = new Scanner(System.in);
		
		File archivo = new File(directorio);
		
		System.out.println("Di el nombre que quieres borrar");
		String nombre = teclado.next();
		File nuevonombre = new File(nombre);
		try {
			if (nuevonombre.delete())
				   System.out.println("Se ha eliminado correctamente");
				 else
				   System.out.println("No se ha podido eliminar");
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	public static void renombrar(String directorio) {
		Scanner teclado = new Scanner(System.in);
		
		File archivo = new File(directorio);
		
		System.out.println("Di el nuevo nombre que quieres poner");
		String nombre = teclado.next();
		System.out.println("Di el archivo que quieres renombrar");
		String nombre2 = teclado.next();
		File nombreantiguo = new File(nombre2);
		File nuevonombre = new File(nombre);
		try {
			if (nombreantiguo.renameTo(nuevonombre))
				   System.out.println("Se ha cambiado el nombre correctamente");
				 else
				   System.out.println("No se ha podido cambiar el nombre");
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	
	
}


